package io.econexion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EconexionApplicationTests {

    @Test
    void contextLoads() {
        // Smoke test: el contexto de Spring arranca
    }
}
