package io.econexion.model;

public enum OfferStatus {
    PENDING,
    ACCEPTED,
    REJECTED
    
}
