package io.econexion.model;

public enum Role {
    BUYER,
    SELLER,
    ADMIN
}
