package io.econexion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EconexionLabApplication {
    public static void main(String[] args) {
        SpringApplication.run(EconexionLabApplication.class, args);
    }
}
